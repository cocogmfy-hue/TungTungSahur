package com.example.tungtungsahur3d;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {
    private final float[] projection = new float[16], view = new float[16], vp = new float[16];
    private final Cube cube = new Cube();
    private int level = 1, hp = 100, bossHp = 100, xp = 0, coins = 0, power = 1, weapon = 0, skin = 0;
    private float heroX = -1.35f, bossX = 1.25f, heroY = 0, jumpV = 0;
    private boolean dead = false, victory = false;
    private long last = System.nanoTime(), lastHit = 0;
    private String[] bossNames = {"SHADOW NOOB", "BANANA BEAST", "CAPPUCCINO TITAN", "FINAL BRAINROT"};
    private String[] weapons = {"Дубинка", "Молот", "Энергоклинок"};
    private float[][] skins = {{0.66f,0.30f,0.12f},{0.12f,0.55f,0.88f},{0.30f,0.72f,0.36f},{0.62f,0.22f,0.72f}};

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.10f, 0.12f, 0.25f, 1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        cube.init();
    }
    @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float)width / Math.max(1, height);
        Matrix.frustumM(projection, 0, -ratio, ratio, -1, 1, 2, 30);
    }
    @Override public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = Math.min(0.04f, (now-last)/1_000_000_000f); last = now;
        if (!dead && !victory) {
            if (bossX > heroX + 0.95f) bossX -= dt * (0.34f + level * 0.035f);
            else if (bossX < heroX + 0.55f) bossX += dt * 0.18f;
            if (Math.abs(bossX-heroX) < 1.05f && now-lastHit > 1_300_000_000L) {
                hp -= Math.max(4, 7 + level); lastHit = now;
                if (hp <= 0) { hp = 0; dead = true; }
            }
            if (heroY > 0) { heroY += jumpV*dt; jumpV -= 5.0f*dt; if (heroY < 0) {heroY=0;jumpV=0;} }
        }
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.setLookAtM(view,0,0,3.6f,8.8f,0,0.8f,0,0,1,0);
        Matrix.multiplyMM(vp,0,projection,0,view,0);
        // floor tiles
        draw(0,-1.0f,0, 10.0f,0.18f,5.0f, 0.18f,0.20f,0.32f);
        for(int i=0;i<10;i++) draw(-4.5f+i, -0.88f, -0.4f, 0.72f,0.035f,4.0f, 0.28f,0.30f,0.43f);
        // distant pillars
        for(int i=0;i<6;i++) draw(-4.5f+i*1.8f,0.1f,-2.8f,0.32f,2.1f,0.32f,0.22f,0.24f,0.40f);
        // hero: stylized wooden Sahur with red sash
        float[] hc=skins[skin%skins.length];
        draw(heroX, -0.05f+heroY, 0, 0.55f,0.95f,0.40f,hc[0],hc[1],hc[2]);
        draw(heroX, 0.72f+heroY, 0, 0.62f,0.56f,0.52f,0.73f,0.45f,0.25f);
        draw(heroX, 0.72f+heroY, 0.275f, 0.10f,0.10f,0.04f,0.03f,0.02f,0.02f);
        draw(heroX+0.17f,0.72f+heroY,0.275f,0.10f,0.10f,0.04f,0.03f,0.02f,0.02f);
        draw(heroX,0.25f+heroY,0.215f,0.57f,0.13f,0.06f,0.86f,0.10f,0.12f);
        // weapon changes shape/colour
        if(weapon==0) draw(heroX+0.43f,0.20f+heroY,0.10f,0.13f,0.78f,0.15f,0.47f,0.25f,0.10f);
        if(weapon==1) { draw(heroX+0.45f,0.18f+heroY,0.1f,0.12f,0.70f,0.12f,0.30f,0.19f,0.08f); draw(heroX+0.48f,0.66f+heroY,0.1f,0.43f,0.34f,0.32f,0.45f,0.48f,0.56f); }
        if(weapon==2) draw(heroX+0.44f,0.25f+heroY,0.1f,0.12f,0.95f,0.12f,0.10f,0.90f,1.0f);
        // boss body and head
        draw(bossX,-0.06f,0,0.88f,1.12f,0.66f,0.28f,0.15f,0.42f);
        draw(bossX,0.83f,0,0.95f,0.82f,0.72f,0.48f,0.27f,0.68f);
        draw(bossX-0.23f,0.85f,0.38f,0.13f,0.13f,0.05f,1.0f,0.08f,0.12f);
        draw(bossX+0.23f,0.85f,0.38f,0.13f,0.13f,0.05f,1.0f,0.08f,0.12f);
        draw(bossX,0.55f,0.37f,0.36f,0.09f,0.05f,0.07f,0.03f,0.10f);
        if (dead || victory) {
            draw(0,0.65f,0.1f,2.3f,0.12f,0.12f,1.0f,0.72f,0.10f);
        }
    }
    private void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b) {
        float[] model=new float[16], mvp=new float[16];
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,vp,0,model,0);
        cube.draw(mvp,r,g,b);
    }
    public synchronized void move(int dir) { if(!dead && !victory) heroX=Math.max(-3.4f,Math.min(1.1f,heroX+dir*0.32f)); }
    public synchronized void jump() { if(heroY==0 && !dead && !victory) { jumpV=3.0f; heroY=0.01f; } }
    public synchronized void attack() {
        if(dead || victory) return;
        if(Math.abs(bossX-heroX)<2.0f) { bossHp-=14+power*3+weapon*4; if(bossHp<=0) winRound(); }
    }
    public synchronized void specialAttack() {
        if(dead || victory) return;
        if(Math.abs(bossX-heroX)<3.2f) { bossHp-=30+power*5+weapon*7; if(bossHp<=0) winRound(); }
    }
    private void winRound() {
        bossHp=0; victory=true; xp+=50; coins+=20+level*5;
    }
    public synchronized void upgrade() { if(coins>=20) {coins-=20;power++;hp=Math.min(100,hp+15);} }
    public synchronized void nextWeapon() { weapon=(weapon+1)%weapons.length; }
    public synchronized void nextSkin() { skin=(skin+1)%skins.length; }
    public synchronized void nextLevel() {
        if(victory) {level++;bossHp=100+level*22;hp=Math.min(100,hp+25);bossX=2.2f;heroX=-1.4f;victory=false;dead=false;}
        else if(dead) {hp=100;bossHp=100+level*22;heroX=-1.4f;bossX=2.2f;dead=false;}
    }
    public synchronized String status() {
        String boss=bossNames[Math.min(level-1,bossNames.length-1)];
        String state=dead?"ПОРАЖЕНИЕ — нажми ДАЛЬШЕ":victory?"ПОБЕДА! Нажми ДАЛЬШЕ":"Босс: "+boss;
        return "TUNG TUNG SAHUR 3D   |   Уровень "+level+"   |   HP "+hp+"   |   Босс HP "+bossHp+
            "   |   XP "+xp+"   |   Монеты "+coins+"   |   Сила "+power+"   |   "+weapons[weapon]+"\n"+state;
    }

    static class Cube {
        private FloatBuffer vertices, colors;
        private int program, posHandle, matrixHandle, colorHandle;
        private static final String VS =
            "uniform mat4 uMVP; attribute vec4 aPosition; void main(){ gl_Position=uMVP*aPosition; }";
        private static final String FS =
            "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";
        void init() {
            float[] v={
                -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
                0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
                -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f,
                0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
                -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f
            };
            float[] tri=new float[108];
            for(int f=0;f<6;f++){
                int src=f*12, dst=f*18;
                int[] idx={0,1,2,0,2,3};
                for(int j=0;j<6;j++) { tri[dst+j*3]=v[src+idx[j]*3]; tri[dst+j*3+1]=v[src+idx[j]*3+1]; tri[dst+j*3+2]=v[src+idx[j]*3+2];}
            }
            vertices=ByteBuffer.allocateDirect(tri.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            vertices.put(tri).position(0);
            int vs=loadShader(GLES20.GL_VERTEX_SHADER,VS), fs=loadShader(GLES20.GL_FRAGMENT_SHADER,FS);
            program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,vs); GLES20.glAttachShader(program,fs); GLES20.glLinkProgram(program);
            posHandle=GLES20.glGetAttribLocation(program,"aPosition");
            matrixHandle=GLES20.glGetUniformLocation(program,"uMVP");
            colorHandle=GLES20.glGetUniformLocation(program,"uColor");
        }
        int loadShader(int type,String source) {
            int s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,source); GLES20.glCompileShader(s); return s;
        }
        void draw(float[] mvp,float r,float g,float b) {
            GLES20.glUseProgram(program);
            vertices.position(0);
            GLES20.glEnableVertexAttribArray(posHandle);
            GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,12,vertices);
            GLES20.glUniformMatrix4fv(matrixHandle,1,false,mvp,0);
            GLES20.glUniform4f(colorHandle,r,g,b,1f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
            GLES20.glDisableVertexAttribArray(posHandle);
        }
    }
}
