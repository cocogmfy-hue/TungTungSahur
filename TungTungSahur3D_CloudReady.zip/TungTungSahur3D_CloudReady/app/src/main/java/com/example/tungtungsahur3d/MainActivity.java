package com.example.tungtungsahur3d;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.speech.tts.TextToSpeech;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.opengl.GLSurfaceView;
import java.util.Locale;

public class MainActivity extends Activity {
    GameRenderer renderer;
    TextView hud;
    TextToSpeech tts;
    ToneGenerator tones;
    boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 75);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("ru", "RU"));
                ttsReady = true;
            }
        });

        FrameLayout root = new FrameLayout(this);
        GLSurfaceView gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        renderer = new GameRenderer();
        gl.setRenderer(renderer);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(18, 10, 18, 0);
        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(16);
        hud.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hud.setShadowLayer(4, 2, 2, Color.BLACK);
        top.addView(hud);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(top, tp);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(12, 0, 12, 12);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button left = btn("◀", v -> renderer.move(-1));
        Button right = btn("▶", v -> renderer.move(1));
        Button jump = btn("ПРЫЖОК", v -> renderer.jump());
        Button hit = btn("УДАР!", v -> { renderer.attack(); soundAndShout(); });
        Button special = btn("СУПЕР", v -> { renderer.specialAttack(); soundAndShout(); });
        Button upgrade = btn("УЛУЧШИТЬ", v -> renderer.upgrade());
        Button weapon = btn("ОРУЖИЕ", v -> renderer.nextWeapon());
        Button skin = btn("СКИН", v -> renderer.nextSkin());
        Button next = btn("ДАЛЬШЕ", v -> renderer.nextLevel());
        controls.addView(left); controls.addView(right); controls.addView(jump);
        controls.addView(hit); controls.addView(special); controls.addView(upgrade);
        controls.addView(weapon); controls.addView(skin); controls.addView(next);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, 74, Gravity.BOTTOM);
        root.addView(controls, cp);
        setContentView(root);

        new android.os.Handler().post(new Runnable() {
            @Override public void run() {
                if (hud != null && renderer != null) hud.setText(renderer.status());
                if (!isFinishing()) new android.os.Handler().postDelayed(this, 200);
            }
        });
    }

    Button btn(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setPadding(3, 2, 3, 2);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 62, 1);
        lp.setMargins(2, 0, 2, 0);
        b.setLayoutParams(lp);
        return b;
    }

    void soundAndShout() {
        if (tones != null) tones.startTone(ToneGenerator.TONE_PROP_ACK, 120);
        if (ttsReady && tts != null) tts.speak("Тунг Тунг Сахур!", TextToSpeech.QUEUE_FLUSH, null, "sahur_shout");
    }

    @Override protected void onPause() { super.onPause(); if (renderer != null) renderer.pause(); }
    @Override protected void onResume() { super.onResume(); if (renderer != null) renderer.resume(); }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (tones != null) tones.release();
        super.onDestroy();
    }
}
